================
SLEPc for Python
================

:Authors:      Lisandro Dalcin, Jose E. Roman
:Contact:      dalcinl@gmail.com, jroman@dsic.upv.es
:Web Site:     https://gitlab.com/slepc/slepc
:Date:         |today|

.. include:: abstract.txt

Contents
========

.. include:: toctree.txt

.. include:: links.txt
