#define  FormInitGuess   forminitguess
#define  FormFunction    formfunction
#define  FormJacobian    formjacobian

#define  FormInitGuess_  forminitguess_
#define  FormFunction_   formfunction_
#define  FormJacobian_   formjacobian_

#define _FormInitGuess  _forminitguess
#define _FormFunction   _formfunction
#define _FormJacobian   _formjacobian

#define _FormInitGuess_ _forminitguess_
#define _FormFunction_  _formfunction_
#define _FormJacobian_  _formjacobian_
